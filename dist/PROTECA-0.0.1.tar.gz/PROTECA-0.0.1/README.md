# proteca
Library for guaranteed backdoor neutralization of machine learning models
